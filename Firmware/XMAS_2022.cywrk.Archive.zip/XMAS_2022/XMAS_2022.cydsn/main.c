/* ========================================
 * This is firmware for a PS4 wireless controller adapter for the Vectrex
 * All of the project documents can be found here ()
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ========================================
 *
 * Code used to send Command and Data to the ST7789 was modified from:
 * 
 * https://github.com/jimmywong2003/PNG-to-RGB565 (isSWAP=TRUE for .bin files) (isSWAP=FALSE for .h files)
 * 
*/
#include "project.h"
#include "ST7789.h"
#include <FS.h>
//#include "test2.h"
#include <stdio.h>


void ST7789_WriteCommand(uint8 cmd);
void ST7789_WriteSmallData(uint8 data);
void ST7789_WriteData(uint8 data[], uint32 length);
void ST7789_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
void Write_To_SPI(uint8 data[], uint32 length);
void ST7789_DrawImage_SD(char *filename);

uint8 SPI_Buffer[100];
char acFilename[20];
const char Dan[] = {"FUN"};
const char Loves[] = {"DOVES"};
const char Becky[] = {"FLIES"};
const char Forever[] = {"FOREVER"};
FS_FILE * pFile;
FS_FIND_DATA fd;


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Clock_1_Start();
    SPIM_Start();
    FS_Init();
   

    for(;;)
    {
        /* Place your application code here. */
        ST7789_Init();
        Pin_LED_Write(0);
        char str[] = {"card.bin"};
        ST7789_DrawImage_SD(str);
        CyDelay(3000);
        ST7789_WriteString(10,0,Dan,Font_16x26, WHITE, BLACK);
        CyDelay(1500);
        ST7789_WriteString((16*3)+10,28,Loves,Font_16x26, WHITE, BLACK);
        CyDelay(1500);
        ST7789_WriteString((16*5)+(16*3)+10,(28+28),Becky,Font_16x26, WHITE, BLACK);
        CyDelay(1500);
        ST7789_WriteString((16*4),200,Forever,Font_16x26, CYAN, BLACK);
        CyDelay(5000);
        for(;;)
        {
            if (FS_FindFirstFile(&fd, "", acFilename, sizeof(acFilename)) == 0) 
            {
                do {
                    ST7789_DrawImage_SD(acFilename);
                    CyDelay(10000);
                } while (FS_FindNextFile (&fd));
            }
            FS_FindClose(&fd);
        }
    }
}

/**
 * @brief Initialize ST7789 controller
 * @param none
 * @return none
 */
void ST7789_Init(void)
{
	//LCD_RST0;
    Control_Reg_Control_Pins_Write(0b00000010);
	CyDelay(50);
    //LCD_RST1;
    Control_Reg_Control_Pins_Write(0b00000011);
    CyDelay(50);
   
    ST7789_WriteCommand(ST7789_SWRESET);
    CyDelay(100);
    ST7789_WriteCommand(ST7789_COLMOD);		//	Set color mode
    ST7789_WriteSmallData(ST7789_COLOR_MODE_16bit);
  	ST7789_WriteCommand(0xB2);				//	Porch control
	uint8_t data[] = {0x0C, 0x0C, 0x00, 0x33, 0x33};
	ST7789_WriteData(data, sizeof(data));
    

	/* Internal LCD Voltage generator settings */
   
    ST7789_WriteCommand(0XB7);				//	Gate Control
    ST7789_WriteSmallData(0x35);			//	Default value
    ST7789_WriteCommand(0xBB);				//	VCOM setting
    ST7789_WriteSmallData(0x20);			//	0.725v (default 0.75v for 0x20)
    ST7789_WriteCommand(0xC0);				//	LCMCTRL
    ST7789_WriteSmallData (0x2C);			//	Default value
    ST7789_WriteCommand (0xC2);				//	VDV and VRH command Enable
    ST7789_WriteSmallData (0x01);			//	Default value
    ST7789_WriteCommand (0xC3);				//	VRH set
    ST7789_WriteSmallData (0x0b);			//	+-4.45v (defalut +-4.1v for 0x0B)
    ST7789_WriteCommand (0xC4);				//	VDV set
    ST7789_WriteSmallData (0x20);			//	Default value
    ST7789_WriteCommand (0xC6);				//	Frame rate control in normal mode
    ST7789_WriteSmallData (0x0F);			//	Default value (60HZ)
    ST7789_WriteCommand (0xD0);				//	Power control
    ST7789_WriteSmallData (0xA4);			//	Default value
    ST7789_WriteSmallData (0xA1);			//	Default value
    
	/**************** Division line ****************/

    
	ST7789_WriteCommand(0xE0);
	{
		uint8_t data[] = {0xD0, 0x04, 0x0D, 0x11, 0x13, 0x2B, 0x3F, 0x54, 0x4C, 0x18, 0x0D, 0x0B, 0x1F, 0x23};
		ST7789_WriteData(data, sizeof(data));
	}

    ST7789_WriteCommand(0xE1);
	{
		uint8_t data[] = {0xD0, 0x04, 0x0C, 0x11, 0x13, 0x2C, 0x3F, 0x44, 0x51, 0x2F, 0x1F, 0x1F, 0x20, 0x23};
		ST7789_WriteData(data, sizeof(data));
	}
    ST7789_WriteCommand (ST7789_INVON);		//	Inversion ON
	ST7789_WriteCommand (ST7789_SLPOUT);	//	Out of sleep mode
  	ST7789_WriteCommand (ST7789_NORON);		//	Normal Display on
  	ST7789_WriteCommand (ST7789_DISPON);	//	Main screen turned on

  	CyDelay(50);
	//ST7789_Fill_Color(LIGHTBLUE);				//	Fill with Black.
    
}

void ST7789_WriteCommand(uint8 cmd)
{

	//LCD_DC0;
    Control_Reg_Control_Pins_Write(0b00000001);
    SPI_Buffer[0] = cmd;
	Write_To_SPI(SPI_Buffer ,1);
}

void ST7789_WriteSmallData(uint8 data)
{
    //LCD_DC1;
    Control_Reg_Control_Pins_Write(0b00000011);
    SPI_Buffer[0] = data;
	Write_To_SPI(SPI_Buffer ,1);
}

void ST7789_WriteData(uint8 data[], uint32 length)
{
    //LCD_DC1;
    Control_Reg_Control_Pins_Write(0b00000011);
    Write_To_SPI(data ,length);
    
}

/**
 * @brief Fill the DisplayWindow with single color
 * @param color -> color to Fill with
 * @return none
 */
void ST7789_Fill_Color(uint16_t color)
{
	uint16_t i;
    uint16_t j;
	ST7789_SetAddressWindow(0, 0, ST7789_WIDTH - 1, ST7789_HEIGHT - 1);

	for (i = 0; i < ST7789_WIDTH; i++)
    {
		for (j = 0; j < ST7789_HEIGHT; j++)
        {
			uint8_t data[] = {color >> 8, color & 0xFF};
			ST7789_WriteData(data, sizeof(data));
		}
    }

}

/**
 * @brief Fill an Area with single color
 * @param xSta&ySta -> coordinate of the start point
 * @param xEnd&yEnd -> coordinate of the end point
 * @param color -> color to Fill with
 * @return none
 */
void ST7789_Fill(uint16_t xSta, uint16_t ySta, uint16_t xEnd, uint16_t yEnd, uint16_t color)
{
	uint16_t i, j;
    if ((xEnd < 0) || (xEnd >= ST7789_WIDTH) || (yEnd < 0) || (yEnd >= ST7789_HEIGHT))	return;
	ST7789_SetAddressWindow(xSta, ySta, xEnd, yEnd);
	for (i = ySta; i <= yEnd; i++)
    {
		for (j = xSta; j <= xEnd; j++) 
        {
			uint8_t data[] = {color >> 8, color & 0xFF};
			ST7789_WriteData(data, sizeof(data));
		}
    }
}

/**
 * @brief Set address of DisplayWindow
 * @param xi&yi -> coordinates of window
 * @return none
 */
void ST7789_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
	uint16_t x_start = x0 + X_SHIFT, x_end = x1 + X_SHIFT;
	uint16_t y_start = y0 + Y_SHIFT, y_end = y1 + Y_SHIFT;

	/* Column Address set */
	ST7789_WriteCommand(ST7789_CASET);
	{
		uint8_t data[] = {x_start >> 8, x_start & 0xFF, x_end >> 8, x_end & 0xFF};
		ST7789_WriteData(data, sizeof(data));
	}

	/* Row Address set */
	ST7789_WriteCommand(ST7789_RASET);
	{
		uint8_t data[] = {y_start >> 8, y_start & 0xFF, y_end >> 8, y_end & 0xFF};
		ST7789_WriteData(data, sizeof(data));
	}
	/* Write to RAM */
	ST7789_WriteCommand(ST7789_RAMWR);
}

/**
 * @brief Draw an Image on the screen
 * @param x&y -> start point of the Image
 * @param w&h -> width & height of the Image to Draw
 * @param data -> pointer of the Image array
 * @return none
 */
void ST7789_DrawImage(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t data[])
{
    uint16 datasize;
    uint16 t;
	if ((x >= ST7789_WIDTH) || (y >= ST7789_HEIGHT))
		return;
	if ((x + w - 1) >= ST7789_WIDTH)
		return;
	if ((y + h - 1) >= ST7789_HEIGHT)
		return;


	ST7789_SetAddressWindow(x, y, x + w - 1, y + h - 1);
    datasize = (x + w) * (y + h); // assumes array data type = uint16
    for (t=0; t < datasize; t++)
    {
        uint8 temp[] = {data[t] >> 8, data[t] & 0xFF};
        ST7789_WriteData(temp, sizeof(temp));
    }
 
}

/**
 * @brief Draw Images on the screen from SD card
 * Image must be 240*240*2 (RGB565)
 * @return none
 */
void ST7789_DrawImage_SD(char *filename)
{
    //uint32 datasize;
    uint32 t;
    uint8 databuff[28850];
    
	ST7789_SetAddressWindow(0, 0, 240 - 1, 240 - 1);
    // datasize = (240 * 240) * 2; 
    pFile = FS_FOpen(filename, "rb");
    if(pFile != 0) 
    {
        // send 115200 bytes (240*240*2)
        for (t=0; t < 4; t++)
        {
            FS_Read(pFile, &databuff, 28800); 
            ST7789_WriteData(databuff, 28800);
        }
    }
    FS_FClose(pFile);
 
}

/**
 * @brief Write a char
 * @param  x&y -> cursor of the start point.
 * @param ch -> char to write
 * @param font -> fontstyle of the string
 * @param color -> color of the char
 * @param bgcolor -> background color of the char
 * @return  none
 */
void ST7789_WriteChar(uint16_t x, uint16_t y, char ch, FontDef font, uint16_t color, uint16_t bgcolor)
{
	uint32_t i, b, j;

	ST7789_SetAddressWindow(x, y, x + font.width - 1, y + font.height - 1);

	for (i = 0; i < font.height; i++) {
		b = font.data[(ch - 32) * font.height + i];
		for (j = 0; j < font.width; j++) {
			if ((b << j) & 0x8000) {
				uint8_t data[] = {color >> 8, color & 0xFF};
				ST7789_WriteData(data, sizeof(data));
			}
			else {
				uint8_t data[] = {bgcolor >> 8, bgcolor & 0xFF};
				ST7789_WriteData(data, sizeof(data));
			}
		}
	}

}


/**
 * @brief Write a string
 * @param  x&y -> cursor of the start point.
 * @param str -> string to write
 * @param font -> fontstyle of the string
 * @param color -> color of the string
 * @param bgcolor -> background color of the string
 * @return  none
 */
void ST7789_WriteString(uint16_t x, uint16_t y, const char *str, FontDef font, uint16_t color, uint16_t bgcolor)
{

	while (*str) {
		if (x + font.width >= ST7789_WIDTH) {
			x = 0;
			y += font.height;
			if (y + font.height >= ST7789_HEIGHT) {
				break;
			}

			if (*str == ' ') {
				// skip spaces in the beginning of the new line
				str++;
				continue;
			}
		}
		ST7789_WriteChar(x, y, *str, font, color, bgcolor);
		x += font.width;
		str++;
	}

}


void Write_To_SPI(uint8 data[], uint32 length)
{
    uint32 temp;
    uint32 x;
    
    // Clear the TX buffer
    SPIM_ClearTxBuffer();
    // Ensure that previous SPI write is done, or SPI is idle before sending data
    temp = SPIM_ReadTxStatus();
    while(!(temp & (SPIM_STS_SPI_DONE | SPIM_STS_SPI_IDLE)));
    // Send the data
    for(x=0; x < length; x++)
    {
        SPIM_WriteTxData(data[x]);
        // Ensure data is sent before returning from function
        while( ! (SPIM_ReadTxStatus() & SPIM_STS_BYTE_COMPLETE  ) );
    }
    
}





/* [] END OF FILE */
